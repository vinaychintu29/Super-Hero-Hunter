# Super-Hero-Hunter
This super-hero hunter application build to search for any superhero ,get details about any superhero and to add these superheroes to favourite list.

# Used Technology
HTML 
CSS
JS
# Introduction
This project is Super Hero Hunter App in which we use superheroAPI() to fetch the records and details of all the superheroes along with some additional features. It is built using HTML, CSS, Vanilla Javascript.

# Link
link https://superhunterss.netlify.app

# Screenshot

 ![1](https://user-images.githubusercontent.com/63258485/192076906-26574695-29fc-4b1d-a828-3d1cd5362d8c.jpg)
![2](https://user-images.githubusercontent.com/63258485/192076911-b50decd6-a291-402b-83eb-7646d5707900.jpg)
![3](https://user-images.githubusercontent.com/63258485/192076915-bd90d4d8-bce6-4430-aa3d-ef9c913e7a74.jpg)


